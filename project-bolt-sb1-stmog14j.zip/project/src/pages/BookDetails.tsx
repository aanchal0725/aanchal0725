import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Star, ShoppingCart, BookOpen, User, Calendar, Package } from 'lucide-react';
import { books } from '../data/books';
import { useCart } from '../contexts/CartContext';

const BookDetails = () => {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  
  const book = books.find(b => b.id === id);

  if (!book) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Book Not Found</h2>
          <Link to="/books" className="text-red-600 hover:text-red-700 font-medium">
            Back to Books
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(book);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link 
          to="/books" 
          className="inline-flex items-center text-red-600 hover:text-red-700 font-medium mb-8"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Books
        </Link>

        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-8">
            {/* Book Image */}
            <div className="space-y-4">
              <div className="relative">
                <img 
                  src={book.image} 
                  alt={book.title}
                  className="w-full max-w-md mx-auto rounded-lg shadow-lg"
                />
                {book.originalPrice && (
                  <div className="absolute top-4 left-4 bg-red-500 text-white text-sm px-3 py-1 rounded">
                    Save NPR {book.originalPrice - book.price}
                  </div>
                )}
              </div>
            </div>

            {/* Book Details */}
            <div className="space-y-6">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{book.title}</h1>
                <p className="text-xl text-gray-600 mb-4">by {book.author}</p>
                
                <div className="flex items-center mb-4">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`h-5 w-5 ${i < Math.floor(book.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                      />
                    ))}
                  </div>
                  <span className="ml-2 text-gray-600">({book.reviews} reviews)</span>
                </div>
              </div>

              {/* Price */}
              <div className="space-y-2">
                <div className="flex items-center space-x-4">
                  <span className="text-3xl font-bold text-red-600">NPR {book.price}</span>
                  {book.originalPrice && (
                    <span className="text-xl text-gray-500 line-through">NPR {book.originalPrice}</span>
                  )}
                </div>
                <p className="text-sm text-gray-600">Cash on Delivery Available</p>
              </div>

              {/* Stock Status */}
              <div>
                <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                  book.stock > 10 
                    ? 'bg-green-100 text-green-800' 
                    : book.stock > 0 
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-red-100 text-red-800'
                }`}>
                  {book.stock > 10 ? 'In Stock' : book.stock > 0 ? `Only ${book.stock} left` : 'Out of Stock'}
                </span>
              </div>

              {/* Add to Cart Button */}
              <button
                onClick={handleAddToCart}
                disabled={book.stock === 0}
                className="w-full bg-red-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-red-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
              >
                <ShoppingCart className="h-5 w-5" />
                <span>{book.stock === 0 ? 'Out of Stock' : 'Add to Cart'}</span>
              </button>

              {/* Book Info */}
              <div className="grid grid-cols-2 gap-4 pt-6 border-t border-gray-200">
                <div className="flex items-center space-x-2">
                  <BookOpen className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{book.pages} pages</span>
                </div>
                <div className="flex items-center space-x-2">
                  <User className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{book.language}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{new Date(book.publishDate).getFullYear()}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Package className="h-4 w-4 text-gray-500" />
                  <span className="text-sm text-gray-600">{book.category}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="border-t border-gray-200 p-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Description</h3>
            <p className="text-gray-700 leading-relaxed">{book.description}</p>
          </div>

          {/* Additional Details */}
          <div className="border-t border-gray-200 p-8 bg-gray-50">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Book Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <span className="font-medium text-gray-700">ISBN:</span>
                <span className="ml-2 text-gray-600">{book.isbn}</span>
              </div>
              <div>
                <span className="font-medium text-gray-700">Publisher:</span>
                <span className="ml-2 text-gray-600">{book.publisher}</span>
              </div>
              <div>
                <span className="font-medium text-gray-700">Publication Date:</span>
                <span className="ml-2 text-gray-600">{new Date(book.publishDate).toLocaleDateString()}</span>
              </div>
              <div>
                <span className="font-medium text-gray-700">Language:</span>
                <span className="ml-2 text-gray-600">{book.language}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookDetails;