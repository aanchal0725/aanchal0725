import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { CheckCircle, Package, Phone, Mail } from 'lucide-react';

interface LocationState {
  orderId: string;
  customerInfo: {
    name: string;
    email: string;
    phone: string;
    address: string;
  };
  total: number;
}

const OrderSuccess = () => {
  const location = useLocation();
  const state = location.state as LocationState;

  if (!state) {
    return (
      <div className="min-h-screen bg-gray-50 py-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Order not found</h2>
          <Link 
            to="/" 
            className="bg-red-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors"
          >
            Go to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-8 text-center">
          <CheckCircle className="mx-auto h-16 w-16 text-green-500 mb-6" />
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Order Placed Successfully!</h1>
          <p className="text-gray-600 mb-8">
            Thank you for your order. We'll process it and deliver your books soon.
          </p>

          <div className="bg-gray-50 rounded-lg p-6 mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Order Details</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium text-gray-700">Order ID:</span>
                <span className="ml-2 text-gray-900 font-mono">{state.orderId}</span>
              </div>
              <div>
                <span className="font-medium text-gray-700">Total Amount:</span>
                <span className="ml-2 text-gray-900 font-bold">NPR {state.total}</span>
              </div>
              <div>
                <span className="font-medium text-gray-700">Customer:</span>
                <span className="ml-2 text-gray-900">{state.customerInfo.name}</span>
              </div>
              <div>
                <span className="font-medium text-gray-700">Payment:</span>
                <span className="ml-2 text-gray-900">Cash on Delivery</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="text-center">
              <Package className="mx-auto h-8 w-8 text-blue-600 mb-2" />
              <h3 className="font-semibold text-gray-900">Processing</h3>
              <p className="text-sm text-gray-600">We'll prepare your order within 24 hours</p>
            </div>
            
            <div className="text-center">
              <Phone className="mx-auto h-8 w-8 text-orange-600 mb-2" />
              <h3 className="font-semibold text-gray-900">Confirmation Call</h3>
              <p className="text-sm text-gray-600">We'll call to confirm your order</p>
            </div>
            
            <div className="text-center">
              <Mail className="mx-auto h-8 w-8 text-green-600 mb-2" />
              <h3 className="font-semibold text-gray-900">Delivery Update</h3>
              <p className="text-sm text-gray-600">You'll receive delivery updates via email</p>
            </div>
          </div>

          <div className="space-y-4">
            <Link
              to="/books"
              className="w-full bg-red-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-red-700 transition-colors inline-block"
            >
              Continue Shopping
            </Link>
            <Link
              to="/"
              className="w-full border border-gray-300 text-gray-700 py-3 px-6 rounded-lg font-medium hover:bg-gray-50 transition-colors inline-block"
            >
              Back to Home
            </Link>
          </div>

          <div className="mt-8 p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>Note:</strong> Please keep your phone available. Our delivery team will call you before arriving at your location.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderSuccess;