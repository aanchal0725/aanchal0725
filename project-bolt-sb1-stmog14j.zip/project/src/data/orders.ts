import { Order } from '../types';

export const orders: Order[] = [
  {
    id: 'ORD001',
    customerName: 'Ram Bahadur Thapa',
    email: 'ram.thapa@email.com',
    phone: '+977-9841234567',
    address: 'Thamel, Ward No. 26',
    city: 'Kathmandu',
    items: [
      {
        book: {
          id: '1',
          title: 'Nepali Sahitya Ko Itihas',
          author: 'Taranath Sharma',
          price: 899,
          image: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
          description: '',
          category: 'Literature',
          isbn: '978-9937-0-1234-5',
          pages: 456,
          language: 'Nepali',
          publisher: 'Sajha Prakashan',
          publishDate: '2023-01-15',
          stock: 25,
          featured: true,
          rating: 4.8,
          reviews: 124
        },
        quantity: 2
      }
    ],
    total: 1798,
    status: 'processing',
    paymentMethod: 'cod',
    orderDate: '2024-01-15T10:30:00Z',
    notes: 'Please call before delivery',
    trackingNumber: 'NB001234567',
    estimatedDelivery: '2024-01-18'
  },
  {
    id: 'ORD002',
    customerName: 'Sita Gurung',
    email: 'sita.gurung@email.com',
    phone: '+977-9851234567',
    address: 'Lakeside, Ward No. 6',
    city: 'Pokhara',
    items: [
      {
        book: {
          id: '4',
          title: 'Modern Nepali Poetry',
          author: 'Madhav Prasad Ghimire',
          price: 699,
          image: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
          description: '',
          category: 'Poetry',
          isbn: '978-9937-0-4567-8',
          pages: 298,
          language: 'Nepali',
          publisher: 'Ratna Pustak Bhandar',
          publishDate: '2023-04-05',
          stock: 31,
          featured: true,
          rating: 4.9,
          reviews: 156
        },
        quantity: 1
      },
      {
        book: {
          id: '6',
          title: 'Nepal Tourism Guide',
          author: 'Prakash Upreti',
          price: 799,
          image: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
          description: '',
          category: 'Travel',
          isbn: '978-9937-0-6789-0',
          pages: 367,
          language: 'English',
          publisher: 'Travel Books Nepal',
          publishDate: '2023-06-20',
          stock: 19,
          featured: true,
          rating: 4.8,
          reviews: 203
        },
        quantity: 1
      }
    ],
    total: 1498,
    status: 'shipped',
    paymentMethod: 'cod',
    orderDate: '2024-01-14T14:20:00Z',
    trackingNumber: 'NB001234568',
    estimatedDelivery: '2024-01-17'
  },
  {
    id: 'ORD003',
    customerName: 'Bishnu Prasad Sharma',
    email: 'bishnu.sharma@email.com',
    phone: '+977-9861234567',
    address: 'Dharan-8, Sukedhara',
    city: 'Dharan',
    items: [
      {
        book: {
          id: '2',
          title: 'Business Management in Nepal',
          author: 'Dr. Ram Kumar Sharma',
          price: 1299,
          image: 'https://images.pexels.com/photos/590020/pexels-photo-590020.jpeg?auto=compress&cs=tinysrgb&w=400',
          description: '',
          category: 'Business',
          isbn: '978-9937-0-2345-6',
          pages: 623,
          language: 'English',
          publisher: 'Educational Publishers',
          publishDate: '2023-03-20',
          stock: 18,
          featured: true,
          rating: 4.6,
          reviews: 89
        },
        quantity: 1
      }
    ],
    total: 1299,
    status: 'delivered',
    paymentMethod: 'cod',
    orderDate: '2024-01-12T09:15:00Z',
    trackingNumber: 'NB001234569',
    estimatedDelivery: '2024-01-15'
  }
];