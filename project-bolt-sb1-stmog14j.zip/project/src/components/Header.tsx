import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Book, User, Menu, X, Package, LogOut } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';

const Header = () => {
  const { getItemCount } = useCart();
  const { state: authState, logout } = useAuth();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = React.useState(false);

  const isActive = (path: string) => location.pathname === path;
  const isAdmin = location.pathname.startsWith('/admin');

  if (isAdmin) {
    return null; // Don't show main header on admin pages
  }

  const handleLogout = () => {
    logout();
    setIsUserMenuOpen(false);
  };

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <Book className="h-8 w-8 text-red-600" />
            <span className="text-xl font-bold text-gray-900">NepalBooks</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link 
              to="/" 
              className={`text-sm font-medium transition-colors ${
                isActive('/') ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
              }`}
            >
              Home
            </Link>
            <Link 
              to="/books" 
              className={`text-sm font-medium transition-colors ${
                isActive('/books') ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
              }`}
            >
              Books
            </Link>
            <Link 
              to="/track-order" 
              className={`flex items-center space-x-1 text-sm font-medium transition-colors ${
                isActive('/track-order') ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
              }`}
            >
              <Package className="h-4 w-4" />
              <span>Track Order</span>
            </Link>
            <Link 
              to="/cart" 
              className={`flex items-center space-x-1 text-sm font-medium transition-colors ${
                isActive('/cart') ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
              }`}
            >
              <ShoppingCart className="h-4 w-4" />
              <span>Cart ({getItemCount()})</span>
            </Link>
            
            {/* User Menu */}
            {authState.isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-1 text-sm font-medium text-gray-700 hover:text-red-600 transition-colors"
                >
                  <User className="h-4 w-4" />
                  <span>{authState.user?.name}</span>
                </button>
                
                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
                    <Link
                      to="/track-order"
                      onClick={() => setIsUserMenuOpen(false)}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      My Orders
                    </Link>
                    <Link
                      to="/admin"
                      onClick={() => setIsUserMenuOpen(false)}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Admin Panel
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      <div className="flex items-center space-x-2">
                        <LogOut className="h-4 w-4" />
                        <span>Sign Out</span>
                      </div>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link 
                to="/login" 
                className="flex items-center space-x-1 text-sm font-medium text-gray-700 hover:text-red-600 transition-colors"
              >
                <User className="h-4 w-4" />
                <span>Sign In</span>
              </Link>
            )}
          </nav>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-md text-gray-700 hover:text-red-600 transition-colors"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-4">
              <Link 
                to="/" 
                onClick={() => setIsMenuOpen(false)}
                className={`text-sm font-medium transition-colors ${
                  isActive('/') ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
                }`}
              >
                Home
              </Link>
              <Link 
                to="/books" 
                onClick={() => setIsMenuOpen(false)}
                className={`text-sm font-medium transition-colors ${
                  isActive('/books') ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
                }`}
              >
                Books
              </Link>
              <Link 
                to="/track-order" 
                onClick={() => setIsMenuOpen(false)}
                className={`flex items-center space-x-1 text-sm font-medium transition-colors ${
                  isActive('/track-order') ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
                }`}
              >
                <Package className="h-4 w-4" />
                <span>Track Order</span>
              </Link>
              <Link 
                to="/cart" 
                onClick={() => setIsMenuOpen(false)}
                className={`flex items-center space-x-1 text-sm font-medium transition-colors ${
                  isActive('/cart') ? 'text-red-600' : 'text-gray-700 hover:text-red-600'
                }`}
              >
                <ShoppingCart className="h-4 w-4" />
                <span>Cart ({getItemCount()})</span>
              </Link>
              
              {authState.isAuthenticated ? (
                <>
                  <div className="text-sm font-medium text-gray-900 border-t pt-4">
                    Welcome, {authState.user?.name}
                  </div>
                  <Link 
                    to="/admin" 
                    onClick={() => setIsMenuOpen(false)}
                    className="text-sm font-medium text-gray-700 hover:text-red-600 transition-colors"
                  >
                    Admin Panel
                  </Link>
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsMenuOpen(false);
                    }}
                    className="flex items-center space-x-2 text-sm font-medium text-gray-700 hover:text-red-600 transition-colors text-left"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Sign Out</span>
                  </button>
                </>
              ) : (
                <Link 
                  to="/login" 
                  onClick={() => setIsMenuOpen(false)}
                  className="flex items-center space-x-1 text-sm font-medium text-gray-700 hover:text-red-600 transition-colors"
                >
                  <User className="h-4 w-4" />
                  <span>Sign In</span>
                </Link>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;